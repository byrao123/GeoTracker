-----------------------------------------------------------------------------------
Project: OpenGTS - Open Source GPS Tracking System
URL    : http://www.opengts.org
File   : README.txt
-----------------------------------------------------------------------------------

- Precompiled DMTP server jar file:
  Source for the jar file "dmtpserv.jar" in this directory may be found in the
  OpenDMTP Java Server project (http://www.opendmtp.org).
  Current version is "OpenDMTP_server-java_1.3.5"

