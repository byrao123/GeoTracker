#!/bin/sh
# -----------------------------------------------------
# This must be executed from the same directory containing the 'dmtpserv.jar' file
java -cp dmtpserv.jar org.opendmtp.server.Version
#
