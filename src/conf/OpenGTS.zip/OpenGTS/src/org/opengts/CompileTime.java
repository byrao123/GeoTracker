package org.opengts;
public class CompileTime
{
    // 2015/11/01 01:52:19 IST
    public static final long COMPILE_TIMESTAMP = 1446322939L;
}
